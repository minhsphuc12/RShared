# Reproducible Research: Peer Assessment 1


## Loading and preprocessing the data

```r
activity <- read.csv("activity.csv")
activity$date <- as.Date(activity$date)
```


## What is mean total number of steps taken per day?

```r
dailySum <- aggregate(activity$steps, list(date = activity$date), function(x) sum(x, 
    na.rm = TRUE))[, 2]
hist(dailySum)
```

![plot of chunk Total Numer of Steps per Day](figure/Total_Numer_of_Steps_per_Day.png) 

```r
mean(dailySum)
```

```
## [1] 9354
```

```r
median(dailySum)
```

```
## [1] 10395
```


## What is the average daily activity pattern?

```r
intervalMean <- aggregate(activity$steps, list(interval = activity$interval), 
    function(x) mean(x, na.rm = TRUE))
plot(intervalMean[, 1], intervalMean[, 2], type = "l", xlab = "interval", ylab = "mean steps")
```

![plot of chunk Average Daily Activity Pattern](figure/Average_Daily_Activity_Pattern.png) 

```r
maxInterval <- intervalMean$interval[which.max(intervalMean[, 2])]
```

The **``835``** 5-minute interval contains the maximum number of steps.

## Imputing missing values

```r
sum(!complete.cases(activity))
```

```
## [1] 2304
```


Fill in all of the missing values in the dataset using the mean for that 5-minute interval:

```r
newActivity <- activity
for (i in which(is.na(activity$steps))) {
    interval <- newActivity[i, "interval"]
    idx <- floor(interval/100) * 12 + (interval%%100)/5 + 1
    newActivity[i, "steps"] <- intervalMean[idx, 2]
}
```



```r
dailySum <- aggregate(newActivity$steps, list(date = newActivity$date), function(x) sum(x))[, 
    2]
hist(dailySum)
```

![plot of chunk Total Number of Steps per Day with Missing Value Filled](figure/Total_Number_of_Steps_per_Day_with_Missing_Value_Filled.png) 

```r
mean(dailySum)
```

```
## [1] 10766
```

```r
median(dailySum)
```

```
## [1] 10766
```


## Are there differences in activity patterns between weekdays and weekends?

```r
isWeekend = is.element(weekdays(newActivity$date), c("Saturday", "Sunday"))
newActivity$dayofweek = factor(isWeekend, levels = c("FALSE", "TRUE"), labels = c("weekday", 
    "weekend"))
```



```r
intervalMean <- aggregate(newActivity$steps, list(dayofweek = newActivity$dayofweek, 
    interval = newActivity$interval), function(x) mean(x))
library(lattice)
xyplot(x ~ interval | dayofweek, intervalMean, layout = c(1, 2), xlab = "Interval", 
    ylab = "Number of steps", type = "l")
```

![plot of chunk Time Series Panel Plot](figure/Time_Series_Panel_Plot.png) 


# Reproducable Research Assigment 1
# https://github.com/leroyJr/RepData_PeerAssessment1


# Load the data
# setwd("C:/Users/Michael/Dropbox/Class/repdata-002/RepData_PeerAssessment1")
# ssetwd("/Users/michaelmatney/Dropbox/Class/repdata-002/RepData_PeerAssessment1")
data <- read.csv('activity.csv')

# Process/Transform the data
# Three columns (steps, date, interval)
# 1k observations
# steps contains NAs
library(data.table)
DT <- data.table(data)

# Find the total steps taken per day [remove interval and sum]
aggs_by_day <- aggregate(DT[,steps], list(Date = DT[,date]), FUN=sum)
colnames(aggs_by_day) <- c("Date", "tot_steps")

# no need to keep the data frame too
rm(data)

# Question: What is the mean total steps taken per day
# 1) Histogram of total steps taken per day
hist(aggs_by_day$tot_steps, breaks=20, col="blue", main="Total Steps Taken by Day", xlab="Daily Total Steps")

# 2) Calculate mean and median steps taken per day
daily_steps.mean <- mean(aggs_by_day$tot_steps, na.rm=TRUE)
daily_steps.median <- median(aggs_by_day$tot_steps, na.rm=TRUE)

# What is the Average Daily Activity Pattern
# 1) Make a time series plot (i.e. type = "l") of the 5-minute interval (x-axis) and the 
#    average number of steps taken, averaged across all days (y-axis)
aggs_by_interval <- aggregate(DT[,steps], list(Interval = DT[,interval]), FUN=mean, na.rm=TRUE)
colnames(aggs_by_interval) <- c("Interval", "steps")
plot(aggs_by_interval$Interval, aggs_by_interval$steps, type="l", main="Mean Number of Steps by 5 minute Interval", ylab="# of steps", xlab="5 Minute Interval")

# 2) Which 5-minute interval, on average across all the days in the dataset, 
#    contains the maximum number of steps?
	# Should report back Interval 835, with an average of 206.1698
aggs_by_interval[aggs_by_interval$steps == max(aggs_by_interval$steps),]


# Imputing missing values

# Note: that there are a number of days/intervals where there are missing values (coded as NA). 
# The presence of missing days may introduce bias into some calculations or summaries of the data.

# 1) Calculate and report the total number of missing values in the dataset 
#    (i.e. the total number of rows with NAs)
nrow(DT[is.na(steps)])

# 2) Devise a strategy for filling in all of the missing values in the dataset. 
#    The strategy does not need to be sophisticated. For example, you could use 
#    the mean/median for that day, or the mean for that 5-minute interval, etc.
# replace with median steps for the interval
DT_missing <- as.data.table(aggregate(DT[,steps], list(interval = DT[,interval]), FUN=median, na.rm=TRUE))
setkey(DT, interval)
setkey(DT_missing, interval)

# 3) Create a new dataset that is equal to the original dataset but with the missing data filled in.
DT_new <- copy(DT)
DT_new <- merge(DT_new, DT_missing)
# replace the missing values with median x for interval from DT_missing
DT_new[,steps := ifelse(is.na(steps), x, steps)]
# check that this worked
nrow(DT_new[is.na(steps)])


# 4) Make a histogram of the total number of steps taken each day and Calculate and 
#    report the mean and median total number of steps taken per day. 
#    Do these values differ from the estimates from the first part of the assignment? 
#    What is the impact of imputing missing data on the estimates of the total daily number of steps?
aggs_by_day_imputed <- aggregate(DT_new[,steps], list(Date = DT_new[,date]), FUN=sum)
colnames(aggs_by_day_imputed) <- c("Date", "tot_steps")
hist(aggs_by_day_imputed$tot_steps, breaks=20, col="green", main="Total Steps Taken by Day", xlab="Daily Total Steps")
mean(aggs_by_day_imputed$tot_steps)
median(aggs_by_day_imputed$tot_steps)

# Are there differences in activity patterns between weekdays and weekends?
#   For this part the weekdays() function may be of some help here. Use the 
#   dataset with the filled-in missing values for this part.

# 1) Create a new factor variable in the dataset with two levels -- "weekday" and 
#    "weekend" indicating whether a given date is a weekday or weekend day.
# determine the day of the week
DT[,day := format(as.Date(date), "%a")]
# classify as weekend: Y or N
DT[,weekend := ifelse(DT[,day] == "Sat" | DT[,day]=="Sun", "Y", "N")]


# 2) Make a panel plot containing a time series plot (i.e. type = "l") of the 5-minute 
#    interval (x-axis) and the average number of steps taken, averaged across all weekday 
#    days or weekend days (y-axis). The plot should look something like the following, 
#    which was creating using simulated data:
library(lattice)
# xyplot(steps~interval|weekend, data=DT_new, type="l")

aggs_by_interval2 <- aggregate(DT[,steps], list(Interval=DT[,interval], Weekend=DT[,weekend]), FUN=mean, na.rm=TRUE)
colnames(aggs_by_interval2) <- c("interval", "weekend", "mean_steps")
xyplot(mean_steps~interval|weekend, data=aggs_by_interval2, type="l")


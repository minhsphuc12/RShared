Reproducable Research Assigment 1
====================
[https://github.com/leroyJr/RepData_PeerAssessment1](https://github.com/leroyJr/RepData_PeerAssessment1)




Load the data
Create separate aggregations by Date, Interval to answer preliminary questions



## Question: What is the mean total steps taken per day?
### 1) Histogram of total steps taken per day

```r
hist(aggs_by_day$tot_steps, breaks = 20, col = "blue", main = "Total Steps Taken by Day")
```

![plot of chunk totalStepsHistogram](figure/totalStepsHistogram.png) 

### 2) Calculate mean and median steps taken per day

```r
mean(aggs_by_day$tot_steps, na.rm = TRUE)
```

```
## [1] 10766
```

```r
median(aggs_by_day$tot_steps, na.rm = TRUE)
```

```
## [1] 10765
```

## What is the Average Daily Activity Pattern?
### 1) Make a time series plot (i.e. type = "l") of the 5-minute interval (x-axis) and the 
average number of steps taken, averaged across all days (y-axis)

```r
plot(aggs_by_interval$Interval, aggs_by_interval$steps, type = "l", main = "Mean Number of Steps by 5 minute Interval", 
    ylab = "# of steps", xlab = "5 Minute Interval")
```

![plot of chunk avgDailyActivityPattern](figure/avgDailyActivityPattern.png) 

### 2) Which 5-minute interval, on average across all the days in the dataset, contains the maximum number of steps?
Should report back Interval 835, with an average of 206.1698

```r
aggs_by_interval[aggs_by_interval$steps == max(aggs_by_interval$steps), ]
```

```
##     Interval steps
## 104      835 206.2
```

Which is consistent with chart showing the same.

## Imputing missing values
Note: that there are a number of days/intervals where there are missing values (coded as NA). 
The presence of missing days may introduce bias into some calculations or summaries of the data.

### 1) Calculate and report the total number of missing values in the dataset 
(i.e. the total number of rows with NAs)

```r
nrow(DT[is.na(steps)])
```

```
## [1] 2304
```

### 2) Devise a strategy for filling in all of the missing values in the dataset. 
Use the median steps for the interval to fill in the missing values.

### 3) Create a new dataset that is equal to the original dataset but with the missing data filled in.

```r
DT_missing <- as.data.table(aggregate(DT[, steps], list(interval = DT[, interval]), 
    FUN = median, na.rm = TRUE))
setkey(DT, interval)
setkey(DT_missing, interval)
DT_new <- copy(DT)
DT_new <- merge(DT_new, DT_missing)
# replace the missing values with median x for interval from DT_missing
DT_new[, `:=`(steps, ifelse(is.na(steps), x, steps))]
```

```
##        interval steps       date x
##     1:        0     0 2012-10-01 0
##     2:        0     0 2012-10-02 0
##     3:        0     0 2012-10-03 0
##     4:        0    47 2012-10-04 0
##     5:        0     0 2012-10-05 0
##    ---                            
## 17564:     2355     0 2012-11-26 0
## 17565:     2355     0 2012-11-27 0
## 17566:     2355     0 2012-11-28 0
## 17567:     2355     0 2012-11-29 0
## 17568:     2355     0 2012-11-30 0
```

```r
# check that this worked
nrow(DT_new[is.na(steps)])
```

```
## [1] 0
```


### 4) Make a histogram of the total number of steps taken each day and Calculate and 
###    report the mean and median total number of steps taken per day. 
Do these values differ from the estimates from the first part of the assignment? 
What is the impact of imputing missing data on the estimates of the total daily number of steps?

```r
aggs_by_day_imputed <- aggregate(DT_new[, steps], list(Date = DT_new[, date]), 
    FUN = sum)
colnames(aggs_by_day_imputed) <- c("Date", "tot_steps")
hist(aggs_by_day_imputed$tot_steps, breaks = 20, col = "green", main = "Total Steps Taken by Day", 
    xlab = "Daily Total Steps")
```

![plot of chunk newHistogram](figure/newHistogram.png) 

```r
mean(aggs_by_day_imputed$tot_steps)
```

```
## [1] 9504
```

```r
median(aggs_by_day_imputed$tot_steps)
```

```
## [1] 10395
```

The mean and median steps pert day have decreased with this attempt to impute missing values.

## Are there differences in activity patterns between weekdays and weekends?
For this part the weekdays() function may be of some help here. Use the 
dataset with the filled-in missing values for this part.

### 1) Create Weekend Factor
Create a new factor variable in the dataset with two levels -- "weekday" and 
"weekend" indicating whether a given date is a weekday or weekend day.

```r
# determine the day of the week
DT[, `:=`(day, format(as.Date(date), "%a"))]
```

```
##        steps       date interval day
##     1:    NA 2012-10-01        0 Mon
##     2:     0 2012-10-02        0 Tue
##     3:     0 2012-10-03        0 Wed
##     4:    47 2012-10-04        0 Thu
##     5:     0 2012-10-05        0 Fri
##    ---                              
## 17564:     0 2012-11-26     2355 Mon
## 17565:     0 2012-11-27     2355 Tue
## 17566:     0 2012-11-28     2355 Wed
## 17567:     0 2012-11-29     2355 Thu
## 17568:    NA 2012-11-30     2355 Fri
```

```r
# classify as weekend: Y or N
DT[, `:=`(weekend, ifelse(DT[, day] == "Sat" | DT[, day] == "Sun", "Weekend", 
    "Weekday"))]
```

```
##        steps       date interval day weekend
##     1:    NA 2012-10-01        0 Mon Weekday
##     2:     0 2012-10-02        0 Tue Weekday
##     3:     0 2012-10-03        0 Wed Weekday
##     4:    47 2012-10-04        0 Thu Weekday
##     5:     0 2012-10-05        0 Fri Weekday
##    ---                                      
## 17564:     0 2012-11-26     2355 Mon Weekday
## 17565:     0 2012-11-27     2355 Tue Weekday
## 17566:     0 2012-11-28     2355 Wed Weekday
## 17567:     0 2012-11-29     2355 Thu Weekday
## 17568:    NA 2012-11-30     2355 Fri Weekday
```


### 2) Panel Plot showing Weekend vs Weekday 
Make a panel plot containing a time series plot (i.e. type = "l") of the 5-minute 
interval (x-axis) and the average number of steps taken, averaged across all weekday 
days or weekend days (y-axis). The plot should look something like the following, 
which was creating using simulated data:

```r
library(lattice)
# xyplot(steps~interval|weekend, data=DT_new, type='l')

aggs_by_interval2 <- aggregate(DT[, steps], list(Interval = DT[, interval], 
    Weekend = DT[, weekend]), FUN = mean, na.rm = TRUE)
colnames(aggs_by_interval2) <- c("interval", "weekend", "mean_steps")
xyplot(mean_steps ~ interval | weekend, data = aggs_by_interval2, type = "l")
```

![plot of chunk latticePlot](figure/latticePlot.png) 

